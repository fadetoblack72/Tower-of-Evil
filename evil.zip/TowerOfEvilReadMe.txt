Tower of Evil

Since this is a very gamey-game and should (hopefully) be fairly challenging,
at least if you don't make optimal decisions, here's a brief overview of mechanics.

CLASS/STATS:
There are three classes available for you to choose from
(no fighter, haha). Class effects the majority of your Stats and your Spells.
MAGE: Mages are intelligent, but weak. This class focuses on casting spells.
As such, it has access to the most spells (and strongest spells) of any class.
PRIEST: Priests are wise, but fragile. However, they posses powerful prayers.
The Priest excels at the pray ability, allowing it to gain health points efficiently.
It's ability to attack and cast spells is average.
THIEF: Thieves are swift, but stupid. This class excels at the Steal mechanic.
While potentially the strongest physical attacker in the game, thieves only get 1 spell.

STRENGTH: Strength increases the viability of your physical attacks and helps your defenses a bit.
CONSTITUTION: Constitution determines your health, and contributes greatly to your physical defenses.
DEXTERITY: Dexterity makes your attacks more accurate, as well as improving your defense and thievery.
INTELLIGENCE: Intelligence plays a small part in many things, but primarily determines the strength of your spells.
WISDOM: Wisdom helps your Prayer and other healing abilities, as well as helping you resist opposing Steals and Spells.
CHARISMA: Charisma can help you if you need convince someone of something... and also helps you steal better and resist spells.

COMBAT:
You have 4 choices whenever you have the initiative in combat.
1. ATTACK: You attack your opponent physically. Pretty simple.
2. MAGIC: This takes you to a spell selection screen where you can choose a Spell.
3. PRAY: Allows you to pray, which is a life-gaining ability. 
You have no Max health, so feel free to try to gain lots of health if that's your perogative.
4. STEAL: Your character attempts to steal something from your enemy.
You have it now, if you succeed, so this amounts to a potentially powerful debuff for your opponent that buffs you.

Brief spell explanation (this is not necessary, but give it a look if youre trying to decide which spell to use)
Mage spells:
BLINDING LIGHT: Blinds your opponent, making them less accurate and easier to steal from.
TELEKINESIS: Is likely to stun your opponent (free turns!), but makes them more resistant to your magic.
FROST BLAST: Slows your enemy, significantly reducing their accuracy.
Priest Spells:
CONDEMNING GLARE: Using this spell makes your physical attacks notably better.
SPIRIT SAP: You gain some health when you hit with this spell.
Thief Spell:
ILLUSION STRIKE: Hitting with this spell makes an enemy easier to hit and steal from.